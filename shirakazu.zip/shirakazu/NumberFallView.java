public class NumberFallView{
    private NumberFallModel model;
    private static final int BOX_MAX = 36;
    private DrawStart start;

    private int[] fieldNumber = new int[BOX_MAX];
    private int score;

    public NumberFallView(NumberFallModel model){
	this.model = model;
	this.fieldNumber = model.getThrowNumber();
	this.score = model.getScore();
	this.start = new DrawStart(this.fieldNumber,score);
	this.start.draw();
    }
       
    public int[] getFieldNumber(){
	return this.fieldNumber;
    }
}