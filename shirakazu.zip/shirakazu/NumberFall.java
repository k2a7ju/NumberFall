public class NumberFall {
    private NumberFallView view;
    private NumberFallModel model;
    //private NumberFallController controller;

    public NumberFall(){
	this.model = new NumberFallModel();
	this.view = new NumberFallView(this.model/*this.model,this.controller*/);
	//this.controller = new NumberFallController(this.view,this.model);
	
    }
    public static void main(String[] args){
	NumberFall play = new NumberFall();
	play.run();
    }
    public void run(){
	
    }



}